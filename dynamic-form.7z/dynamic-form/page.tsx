import PageHeading from "@/components/custom/PageHeading";
import SampleForm from "./SampleForm";

export default async function Page( ) {
    return (
        <div className="p-4 pt-0">
            <PageHeading heading="Sample form" />
            {<SampleForm /> }
        </div>
    );
}