/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';
import { Form } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import React, { useEffect, useState } from "react";
import { TextareaController } from "@/components/form.controls/TextareaController";
import { showErrorToast, showSuccessToast } from "@/components/custom/Toast";

const UpdateSchemaForm = () => {
  const form = useForm({
    defaultValues: {
      json: ""
    }
  });

  const [formFields, setFormFields] = useState<object>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadFormData() {
      try {
        const data = await fetchFormMetadata();
        setFormFields(data);
        form.setValue('json', JSON.stringify(data, null, 2))
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    loadFormData();
  }, [form]);

  const onSubmit = async (data: any) => {
    try {
      const update = JSON.parse(data.json);
      const res = await updateFormMetadata(update);
      if (res) {
        showSuccessToast("Form metadata updated successfully");
      } else {
        showErrorToast("Failed to update form metadata");
      }
    } catch (error) {
      console.error("Invalid JSON:", error);
      showErrorToast("Invalid JSON");
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        {formFields && <TextareaController name={"json"} label={"Schema"} rows={20} />}
        <div className='flex justify-end gap-2'>
          <Button type="submit">Submit</Button>
        </div>
      </form>
    </Form>
  );
};

export default UpdateSchemaForm;

async function fetchFormMetadata() {
  const res = await fetch('/api/json-data');
  if (!res.ok) {
    throw new Error('Failed to fetch form metadata');
  }
  return await res.json();
}

async function updateFormMetadata(updatedMetadata) {
  const res = await fetch('/api/json-data', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(updatedMetadata),
  });
  if (res.ok) {
    return true
  } else {
    return false
  }
}