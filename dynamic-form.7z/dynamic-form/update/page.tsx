import PageHeading from "@/components/custom/PageHeading";
import UpdateSchemaForm from "./UpdateSchemaForm";

export default function Page() {
    return (
        <div className="p-4 pt-0">
            <PageHeading heading="Update schema" description="This will update form schema"/>
            <UpdateSchemaForm />
        </div>
    );
}